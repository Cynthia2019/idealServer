## latest update: Feb 8th
## writtn by Doksoo Lee (dslee@u.northwestern.edu)
from DPPlibrary import *
from pandas import read_csv
import numpy as np
from scipy.spatial.distance import pdist, squareform

## loading data (from a csv file)
data = read_csv("./data/lattice_2d.csv")  ## can this be replaced with an URL?
# data = read_csv("./data/freeform_2d.csv") 
column_name = list(data.columns)
idx = []
C_list = ['C11', 'C12', 'C22', 'C16', 'C26', 'C66']
for i in range(len(column_name)):
    if column_name[i] in C_list:
        idx.append(i)
prop = []
idx_nonzero = []
C_list = []
for i in idx: # finding the columns with zero only
    if sum(data[column_name[i]]!=0):
        prop.append( data[column_name[i]] )
        idx_nonzero.append(i)
        C_list.append(column_name[i])
idx = idx_nonzero
prop_raw = (np.array(prop).T)
prop = prop_raw

## data normalization
n_data = len(prop_raw)
n_threshold = 1000
if n_data <= n_threshold:
    deno = pdist(prop).mean()
else:
    tmp = np.arange(n_data)
    np.random.shuffle(tmp)
    idx_rnd = tmp[:n_threshold]
    deno = pdist(prop[idx_rnd]).mean()
prop = prop_raw / deno
def standardize(data):  # component-wise standardization
    return (data-np.mean(data, axis=0))/np.std(data, axis=0) 
prop = standardize(prop)

## property diversity
idx_left = np.arange(len(prop))
D_feature = 3000  # for N(ground set) >= 10k, approximation must be used to avoid too much overhead 
batch_size = 20   # for N(subset) >= 100, it's recommended to iterate with a small batch size (e.g., 200 = 20 iter x 10)
if n_data <= 3000: # greedy algorithm
    C = decompose_kernel(squareform(pdist(prop)))
    idx_abs = sample_k(C['D'], batch_size)
else: # approximated algorithm (based on Fourier feature)
    Vp = RFF(prop, D_feature) 
    _, idx_abs, _ = k_Markov_dual_DPP(Vp, idx_left, batch_size=batch_size)
    
## diversity of the subset (mean Euclidean distance)
mean_dist_standardized = np.mean(pdist(prop[idx_abs])) # mean Euclidean distance of standardized property
mean_dist_raw = np.mean(pdist(prop_raw[idx_abs]))      # mean Euclidean distance of raw property
print(np.round(mean_dist_standardized, 3), np.round(mean_dist_raw, 3))